<h2 class="heading" style="color: #495057;"><?= $emailData['subject'] ?></h2>

<?= $emailData['message'] ?>
